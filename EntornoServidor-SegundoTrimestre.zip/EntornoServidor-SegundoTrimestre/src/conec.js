const express = require('express');
const app = express();
const morgan = require('morgan');
const mysql = require('mysql');

//Configuraciones
app.set('port', process.env.PORT || 3000);
app.set('json spaces', 2)

//Middleware
app.use(morgan('dev'));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

var con = mysql.createConnection({
    host: "localhost",
    database: "prt1servidor",
    user: "root",
    password: "",
    port: "3307"
});

con.connect(function(err) {
    if (err) throw err;
    console.log('Connected!');

});

//APARTADO 1
app.get('/TOTALusuario', (req, res) => {
    //const id = req.query.idUsuario;
    
    const sql = "SELECT * FROM datosusuario";
    con.query(sql, (err, result) => {
        if (err) throw err;

        res.json(result);
    });
});

//APARTADO 2
app.get('/datosusuario', (req, res) => {
    const id = req.query.idUsuario;
    
    const sql = "SELECT * FROM datosusuario where idUsuario=" + id ;
    con.query(sql, (err, result) => {
        if (err) throw err;

        res.json(result);
    });
});


//APARTADO 3
app.get('/ListaV', (req, res) => {

    const id = req.query.idUsuario;
    
    const sql = "SELECT * FROM listavehiculo where idUsuario=" + id ;
    con.query(sql, (err, result) => {
        if (err) throw err;

        res.json(result);
    });
});


//APARTADO 4
app.get('/InfoV', (req, res) => {
    
    const id = req.query.idVehiculo;
    
    const sql = "SELECT * FROM listavehiculo where idVehiculo=" + id ;
    con.query(sql, (err, result) => {
        if (err) throw err;

        res.json(result);
    });
});


//APARTADO 5
app.get('/ListaS', (req, res) => {
    
    const id = req.query.idVehiculo;
    
    const sql = "SELECT * FROM listaservicios where idVehiculo=" + id ;
    con.query(sql, (err, result) => {
        if (err) throw err;

        res.json(result);
    });
});


//APARTADO 6
app.get('/InfoS', (req, res) => {
    
    const id = req.query.idServicio;
    
    const sql = "SELECT * FROM listaservicios where idServicio=" + id ;
    con.query(sql, (err, result) => {
        if (err) throw err;

        res.json(result);
    });
});


//APARTADO 7
app.post('/ActualizarUsu', (req, res) => {

    //let id = req.params.idUsuario;
    //let body = _.pick(req.body, ['nombre', 'login', 'fecha_alta', 'num_vehiculos', 'password']);
    let name = req.body.nombre;

    User.findByIdAndUpdate(id, body, {new: true, runValidators: true}, (err, userBD) => {
        if(err){
            return res.status(400).json({
               ok: false,
               err: err
            }); 
        }

        res.json({
            ok: true,
            usuario: userBD
        });
    });
});




//Iniciando el servidor, escuchando...
app.listen(app.get('port'),()=>{
  console.log(`Server listening on port ${app.get('port')}`);
});