const express = require('express');
const app = express();
const morgan = require('morgan');
const mysql = require('mysql');

//Configuraciones
app.set('port', process.env.PORT || 3000);
app.set('json spaces', 2)

//Middleware
app.use(morgan('dev'));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

var con = mysql.createConnection({
    host: "localhost",
    database: "prt1servidor",
    user: "root",
    password: "",
    port: "3307"
});

con.connect(function(err) {
    if (err) throw err;
    console.log('Connected!');

});

app.post('/editUsuario',(req,res) => {
  const id_usu= req.body.id_usu;
  const name = req.body.nombre;
  const dni = req.body.dni;
  const sql= "update usuarios set nombre=" + name + "set dni=" + dni + "";
  
  con.query(sql,(err,result) =>{
      if (err) throw err;

      res.json(result);
  });
});

app.get('/usuario', (req, res) => {
    const id = req.query.idUsuario;
    const nombre = req.query.nombre;

    const sql = "SELECT * from usuarios where id_user=" + id + " and login='" + nombre + "'";
    con.query(sql, (err, result) => {
        if (err) throw err;

        res.json(result);
    });
});

//Iniciando el servidor, escuchando...
app.listen(app.get('port'),()=>{
  console.log(`Server listening on port ${app.get('port')}`);
});