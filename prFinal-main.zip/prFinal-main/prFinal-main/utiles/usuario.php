<?php 

	function passCheck($login,$pwd,$conDb){

		$queryPass = "SELECT password FROM datosusuario WHERE login = '$login'";
		$resPass = mysqli_query($conDb,$queryPass);

		if($resPass){

			if(mysqli_num_rows($resPass)>0){
				while($row = mysqli_fetch_assoc($resPass)){
					$pwdHashed = $row['password'];
				}
			
				if(password_verify($pwd,$pwdHashed)){
					return true;
				}else{
					return false;
				}
			}

		}

	}


	function allDatafromLogin($login,$conDb){
		$queryLogin = "SELECT * from datosusuario WHERE login='$login'";

		$res = mysqli_query($conDb,$queryLogin);

		if($res){
			if(mysqli_num_rows($res)>0){
				while($row = mysqli_fetch_assoc($res)){
					$allData = $row;
				}
				return $allData;
			}else{
				return null;
			}
		}

	}

	function allDatafromId($idUsuario,$conDb){
		$queryLogin = "SELECT * from datosusuario WHERE idUsuario='$idUsuario'";

		$res = mysqli_query($conDb,$queryLogin);

		if($res){
			if(mysqli_num_rows($res)>0){
				while($row = mysqli_fetch_assoc($res)){
					$allData = $row;
				}
				return $allData;
			}else{
				return null;
			}
		}

	}



?>