<?php 

	function allVehfromId($idUsuario,$conDb){
		$sqlVehiculos = "SELECT * FROM listavehiculo WHERE idUsuario='$idUsuario'";
        $resVehiculos = mysqli_query($conDb,$sqlVehiculos);

        if($resVehiculos){
            if(mysqli_num_rows($resVehiculos)>0){

                while($row = mysqli_fetch_all($resVehiculos)){

                    $allVeh = $row;

                }
                return $allVeh;
            }else{
            	return null;
            }
        }
	}

	function updateVeh($matricula,$marca,$modelo,$idVehiculo,$conDb){
		$sqlUpdate = "UPDATE listavehiculo SET Matricula='$matricula', Marca='$marca', Modelo='$modelo' WHERE idVehiculo='$idVehiculo'";
		$queryUpdate = mysqli_query($conDb,$sqlUpdate);

		if($queryUpdate){
           	return true;
		}else{
			return false;
		}
	}


?>