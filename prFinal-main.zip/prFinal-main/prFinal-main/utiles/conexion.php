<?php
    
    function connect(){
        try{
            $db_host = "localhost";
            $db_name = "prt1servidor";
            $db_user = "root";
            $db_pass = "";

            return mysqli_connect($db_host, $db_user, $db_pass, $db_name);

        }catch(Exception $e){
            die("No se puede establecer conexión con la base de datos");
        }
    }

?>