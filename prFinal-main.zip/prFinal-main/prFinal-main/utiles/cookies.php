<?php 

	function mostrarCookies(){
		$inTwoMonths = 60 * 60 * 24 * 60 + time();
        setcookie('lastVisit', date("G:i - m/d/y"), $inTwoMonths);
        if(isset($_COOKIE['lastVisit'])){
	        $visit = $_COOKIE['lastVisit'];
	        echo "Tu última visita fue - ". $visit;
        }else{
        	echo "No tienes cookies";
        }
	}

?>